- Execute the following commands in "Code" directory to show the results of the first requirement:

* pip install -r requirements.txt

* python beam_sensor_model.py


- You can run "solver.ipynb" to show all the outputs of the first and second requirements